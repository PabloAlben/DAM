public class App {

    public App(){

    }

    public void sayHello(){
        System.out.println("Hola Mundo");
    }

}

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {


        Scanner teclado = new Scanner(System.in);
        int num1;
        int num2;

        do {
            System.out.println("dime el primer numero");
            num1 = teclado.nextInt();
            System.out.println("dime el segundo numero");
            num2 = teclado.nextInt();
        }while(num2 < num1 || num1 < 0);
             intervalo(num1,num2);
    }

    public static void intervalo(int num1, int num2){
        int suma = 0;
        boolean primo = false;
        while(num1 <= num2){

            System.out.println(num1);
            suma += num1;
            for (int i = 1;i < num1;i++){
                if (num1%i == 0 && i != 1){
                     primo = false;
                     break;
                }else {
                    primo = true;
                }
            }
            if (primo)System.out.println("Es primo");
            if (!primo)System.out.println("No es primo");

            primo = false;
            num1++;
        }

        System.out.println("La suma de todos los numeros es: " + suma);

    }


}
import java.util.ArrayList;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
          Scanner teclado = new Scanner(System.in);

          System.out.println("escribe 1 para array y 2 para lista");

    switch (teclado.nextInt()) {
        case 1:
        System.out.println("cuantos numeros vas a introducir");
        int num[] = new int[teclado.nextInt()];

        for (int i = 0; i < num.length; i++) {
            System.out.println("Dime un numero");
            num[i] = teclado.nextInt();
        }

        mayor_Array(num);
        break;
        case 2:

            ArrayList<Integer> nums = new ArrayList<>();
            int numintro = 0;
            boolean salir = false;
            do{

                System.out.println("Dime un numero");
                     nums.add(teclado.nextInt());
                System.out.println("pulsa 1 para salir");
                if (teclado.nextInt() == 1)salir = true;

            }while(!salir);

                 mayor_Lista(nums);
            break;
        default:
            System.out.println("No valido");
    }

    }

    public static void mayor_Array(int conjunto []){
          int mayor = conjunto[0];
          String resultado = "";
          String companyeros[] = new String[6];
          companyeros[0] = "Gonzalo";
          companyeros[1] = "Pablo";
          companyeros[2] = "Alberto";
          companyeros[3] = "Daniela";
          companyeros[4] = "Quique";
          companyeros[5] = "Carles";

          for (int i =0;i < conjunto.length;i++){
              if (mayor < conjunto[i]){
                  mayor = conjunto[i];
              }
              if (conjunto[i] < 6 && conjunto[i] >= 0){
                  resultado +="\n" + " El numero: " + conjunto[i] + " Pertenece al compañero: " + companyeros[conjunto[i]];
              }
          }
          System.out.println("El numero mas grande es: " + mayor + resultado);
    }

    public static void mayor_Lista(ArrayList<Integer> conjunto){
        int mayor = conjunto.get(0);
        String resultado = "";
        String companyeros[] = new String[6];
        companyeros[0] = "Gonzalo";
        companyeros[1] = "Pablo";
        companyeros[2] = "Alberto";
        companyeros[3] = "Daniela";
        companyeros[4] = "Quique";
        companyeros[5] = "Carles";

        for (int i =0;i < conjunto.size();i++){
            if (mayor < conjunto.get(i)){
                mayor = conjunto.get(i);
            }
            if (conjunto.get(i) < 6 && conjunto.get(i) >= 0){
                resultado +="\n" + " El numero: " + conjunto.get(i) + " Pertenece al compañero: " + companyeros[conjunto.get(i)];
            }
        }
        System.out.println("El numero mas grande es: " + mayor + resultado);
    }

}